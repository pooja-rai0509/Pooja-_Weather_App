import React from "react";
import "./App.css";
import WeatherDashboard from "./components/WeatherDashboard";

function App() {
  return (
    <>
      <WeatherDashboard />;
    </>
  );
}

export default App;

import React, { useState } from "react";
import "./weatherDashboard.css";

function WeatherDashboard() {
  const [city, setCity] = useState("");
  const [weather, setWeather] = useState(null);

  const apiKey = "f00c38e0279b7bc85480c3fe775d518c";

  const fetchWeatherData = async () => {
    try {
      const response = await fetch(
        `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`
      );
      const data = await response.json();
      setWeather(data);
    } catch (error) {
      console.error("Error fetching weather data:", error);
    }
  };

  const handleSearch = () => {
    if (city.trim() !== "") {
      fetchWeatherData();
    }
  };
  return (
    <>
      <div className="container">
        <div className="App">
          <h1>Weather Dashboard</h1>
          <div className="search">
            <input
              type="text"
              placeholder="Enter city name..."
              value={city}
              onChange={(e) => setCity(e.target.value)}
            />
            <button onClick={handleSearch}>
              <i className="fa-solid fa-magnifying-glass" />
            </button>
          </div>
          {weather && (
            <div className="weather-details">
              <h2>
                <i className="fa-solid fa-cloud-sun" />
                {weather.name}, {weather.sys.country}
              </h2>
              <p>
                <i className="fa-solid fa-temperature-three-quarters" />
                Temperature: {weather.main.temp}°C
              </p>
              <p>
                <i className="fa-solid fa-droplet" />
                Humidity: {weather.main.humidity}%
              </p>
              <p>
                <i className="fa-solid fa-wind" />
                Wind Speed: {weather.wind.speed} m/s
              </p>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

export default WeatherDashboard;
